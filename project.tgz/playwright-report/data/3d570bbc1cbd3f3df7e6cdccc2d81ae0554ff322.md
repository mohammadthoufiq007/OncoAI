# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: tier1-feature-coverage.spec.ts >> Tier 1: Feature Coverage (70 Test Cases) >> Feature 13: Patient Similarity Engine >> [TC-T1-F13-001] Similarity Search Input
- Location: tests\e2e\specs\tier1-feature-coverage.spec.ts:414:5

# Error details

```
Error: browserType.launch: Executable doesn't exist at C:\Users\Thoufiq\AppData\Local\ms-playwright\webkit-2311\Playwright.exe
╔════════════════════════════════════════════════════════════╗
║ Looks like Playwright was just installed or updated.       ║
║ Please run the following command to download new browsers: ║
║                                                            ║
║     npx playwright install                                 ║
║                                                            ║
║ <3 Playwright Team                                         ║
╚════════════════════════════════════════════════════════════╝
```