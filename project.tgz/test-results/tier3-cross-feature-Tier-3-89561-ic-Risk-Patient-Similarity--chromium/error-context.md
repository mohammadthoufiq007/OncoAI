# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: tier3-cross-feature.spec.ts >> Tier 3: Cross-Feature Integration (14 Test Cases) >> [TC-T3-INT-009] M9 + M10 (Genetic Risk & Patient Similarity)
- Location: tests\e2e\specs\tier3-cross-feature.spec.ts:36:3

# Error details

```
Error: browserType.launch: Executable doesn't exist at C:\Users\Thoufiq\AppData\Local\ms-playwright\chromium_headless_shell-1228\chrome-headless-shell-win64\chrome-headless-shell.exe
╔════════════════════════════════════════════════════════════╗
║ Looks like Playwright was just installed or updated.       ║
║ Please run the following command to download new browsers: ║
║                                                            ║
║     npx playwright install                                 ║
║                                                            ║
║ <3 Playwright Team                                         ║
╚════════════════════════════════════════════════════════════╝
```