# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: tier2-boundary-edge.spec.ts >> Tier 2: Boundary & Edge Cases (70 Test Cases) >> Feature 5: Cancer Classification (Edge Cases) >> [TC-T2-F05-004] Redraw Chart on Resize
- Location: tests\e2e\specs\tier2-boundary-edge.spec.ts:121:5

# Error details

```
Error: browserType.launch: Executable doesn't exist at C:\Users\Thoufiq\AppData\Local\ms-playwright\firefox-1532\firefox\firefox.exe
╔════════════════════════════════════════════════════════════╗
║ Looks like Playwright was just installed or updated.       ║
║ Please run the following command to download new browsers: ║
║                                                            ║
║     npx playwright install                                 ║
║                                                            ║
║ <3 Playwright Team                                         ║
╚════════════════════════════════════════════════════════════╝
```