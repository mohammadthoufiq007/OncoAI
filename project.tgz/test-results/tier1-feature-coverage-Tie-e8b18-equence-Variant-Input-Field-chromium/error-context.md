# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: tier1-feature-coverage.spec.ts >> Tier 1: Feature Coverage (70 Test Cases) >> Feature 12: Genetic Risk Assessment >> [TC-T1-F12-001] Sequence Variant Input Field
- Location: tests\e2e\specs\tier1-feature-coverage.spec.ts:378:5

# Error details

```
Error: browserType.launch: Executable doesn't exist at C:\Users\Thoufiq\AppData\Local\ms-playwright\chromium_headless_shell-1228\chrome-headless-shell-win64\chrome-headless-shell.exe
╔════════════════════════════════════════════════════════════╗
║ Looks like Playwright was just installed or updated.       ║
║ Please run the following command to download new browsers: ║
║                                                            ║
║     npx playwright install                                 ║
║                                                            ║
║ <3 Playwright Team                                         ║
╚════════════════════════════════════════════════════════════╝
```