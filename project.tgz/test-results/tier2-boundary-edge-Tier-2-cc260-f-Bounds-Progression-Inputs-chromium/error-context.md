# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: tier2-boundary-edge.spec.ts >> Tier 2: Boundary & Edge Cases (70 Test Cases) >> Feature 7: Tumor Progression (Edge Cases) >> [TC-T2-F07-005] Out-of-Bounds Progression Inputs
- Location: tests\e2e\specs\tier2-boundary-edge.spec.ts:140:5

# Error details

```
Error: browserType.launch: Executable doesn't exist at C:\Users\Thoufiq\AppData\Local\ms-playwright\chromium_headless_shell-1228\chrome-headless-shell-win64\chrome-headless-shell.exe
╔════════════════════════════════════════════════════════════╗
║ Looks like Playwright was just installed or updated.       ║
║ Please run the following command to download new browsers: ║
║                                                            ║
║     npx playwright install                                 ║
║                                                            ║
║ <3 Playwright Team                                         ║
╚════════════════════════════════════════════════════════════╝
```