# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: tier2-boundary-edge.spec.ts >> Tier 2: Boundary & Edge Cases (70 Test Cases) >> Feature 8: Survival Prediction (Edge Cases) >> [TC-T2-F08-003] Zero-Month Survival Boundary
- Location: tests\e2e\specs\tier2-boundary-edge.spec.ts:147:5

# Error details

```
Error: browserType.launch: Executable doesn't exist at C:\Users\Thoufiq\AppData\Local\ms-playwright\firefox-1532\firefox\firefox.exe
╔════════════════════════════════════════════════════════════╗
║ Looks like Playwright was just installed or updated.       ║
║ Please run the following command to download new browsers: ║
║                                                            ║
║     npx playwright install                                 ║
║                                                            ║
║ <3 Playwright Team                                         ║
╚════════════════════════════════════════════════════════════╝
```